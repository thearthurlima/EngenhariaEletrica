%   Resolve sistema triangular inferior Lx = c pelas substituições sucessivas
%   L = Matriz triangular inferior
%   x = vetor solução
%   c = vetor independente

function [x] = subst_sucessivas(L, c)
    n = length(L);
    x = zeros(1, n); % Aloca um vetor de zeros 
    x(1) = c(1)/L(1,1);
    for i = 2:n
        soma = 0;
        for j = 1:i-1
            soma = soma + L(i,j)*x(j);
        end
        x(i) = (c(i) - soma)/L(i,i);
    end
end