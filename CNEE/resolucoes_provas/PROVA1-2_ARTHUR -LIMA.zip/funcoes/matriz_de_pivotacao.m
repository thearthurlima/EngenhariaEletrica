%   Calcula a matriz pivot a partir do vetor pivot

function [matriz_pivot] = matriz_de_pivotacao(pivot)
    n = length(pivot);
    matriz_I = eye(n);
    matriz_pivot = matriz_I(pivot, :);
end